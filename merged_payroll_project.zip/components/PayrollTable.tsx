import styles from "./PayrollTable.module.css"
import { PayrollLine } from "@/lib/types"
import { formatMoney } from "@/lib/utils"

export function PayrollTable({ lines, currency }: { lines: PayrollLine[]; currency: string }) {
  return (
    <div className={styles.wrap}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th className={styles.th}>Component</th>
            <th className={styles.th}>Category</th>
            <th className={styles.th}>Amount</th>
            <th className={styles.th}>Notes</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i}>
              <td className={styles.td}>{l.label}</td>
              <td className={styles.td}>
                <span className={styles.badge}>{l.category.replaceAll("_", " ")}</span>
              </td>
              <td className={[styles.td, styles.mono].join(" ")}>{formatMoney(l.amount, currency)}</td>
              <td className={styles.td}>{l.note || "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}