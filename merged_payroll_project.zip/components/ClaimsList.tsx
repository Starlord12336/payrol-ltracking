import { useEffect, useState } from "react"
import styles from "./ClaimsList.module.css"
import type { Dispute } from "@/lib/types"

export function ClaimsList({ refresh }: { refresh: number }) {
  const [items, setItems] = useState<Dispute[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    async function load() {
      setLoading(true)
      const res = await fetch("/api/disputes", { cache: "no-store" as any })
      const data = (await res.json().catch(() => [])) as Dispute[]
      if (!cancelled) {
        setItems(Array.isArray(data) ? data : [])
        setLoading(false)
      }
    }
    load()
    return () => {
      cancelled = true
    }
  }, [refresh])

  return (
    <section className={styles.card}>
      <div className={styles.head}>
        <div className={styles.title}>Tracked requests</div>
        <div className={styles.badge}>{loading ? "Loading" : `${items.length} item(s)`}</div>
      </div>

      {loading ? (
        <div className={styles.empty}>Loading...</div>
      ) : items.length ? (
        <div className={styles.list}>
          {items.map(i => (
            <div key={i.id} className={styles.item}>
              <div className={styles.badge}>{i.type.toUpperCase()}</div>
              <div className={styles.meta}>
                <span className={styles.badge}>{i.status}</span>
                {i.payslipId ? <span className={styles.badge}>Payslip: {i.payslipId}</span> : null}
                <span className={styles.badge}>Created: {new Date(i.createdAtISO).toLocaleString()}</span>
              </div>
              <div className={styles.desc}>{i.description}</div>
              {i.attachmentName ? <div className={styles.meta}>Attachment: {i.attachmentName}</div> : null}
            </div>
          ))}
        </div>
      ) : (
        <div className={styles.empty}>No disputes or claims yet.</div>
      )}
    </section>
  )
}