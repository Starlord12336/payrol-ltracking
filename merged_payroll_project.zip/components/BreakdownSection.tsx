import styles from "./BreakdownSection.module.css"
import { formatMoney } from "@/lib/utils"

export function BreakdownSection({
  title,
  currency,
  items
}: {
  title: string
  currency: string
  items: { label: string; amount: number; type: "credit" | "debit"; note?: string }[]
}) {
  if (!items.length) return null
  return (
    <section className={styles.section}>
      <h3 className={styles.title}>{title}</h3>
      <div>
        {items.map((i, k) => (
          <div key={k} className={styles.row}>
            <div>
              <div className={styles.label}>{i.label}</div>
              {i.note ? <div className={styles.note}>{i.note}</div> : null}
            </div>
            <div
              className={[
                styles.amount,
                i.type === "credit" ? styles.credit : styles.debit
              ].join(" ")}
            >
              {formatMoney(i.amount, currency)}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}