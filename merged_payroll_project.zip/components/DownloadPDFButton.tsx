import styles from "./DownloadPDFButton.module.css"

export function DownloadPDFButton({ payslipId }: { payslipId: string }) {
  return (
    <a className={[styles.btn, styles.small].join(" ")} href={`/api/payslips/${payslipId}/pdf`} target="_blank" rel="noreferrer">
      Download PDF
    </a>
  )
}