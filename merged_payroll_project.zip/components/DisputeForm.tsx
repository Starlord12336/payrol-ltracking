import { useMemo, useState } from "react"
import styles from "./DisputeForm.module.css"

type Mode = "dispute" | "claim"

export function DisputeForm({ onDone }: { onDone?: () => void }) {
  const [type, setType] = useState<Mode>("dispute")
  const [payslipId, setPayslipId] = useState("")
  const [description, setDescription] = useState("")
  const [file, setFile] = useState<File | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const canSubmit = useMemo(() => {
    if (busy) return false
    if (!description.trim() || description.trim().length < 5) return false
    if (type === "dispute" && !payslipId.trim()) return false
    return true
  }, [busy, description, payslipId, type])

  async function fileToBase64(f: File) {
    return new Promise<string>((resolve, reject) => {
      const reader = new FileReader()
      reader.onerror = () => reject(new Error("Failed to read file"))
      reader.onload = () => resolve(String(reader.result || ""))
      reader.readAsDataURL(f)
    })
  }

  async function submit() {
    setError(null)
    setBusy(true)
    try {
      const payload: any = {
        type,
        description: description.trim()
      }
      if (type === "dispute") payload.payslipId = payslipId.trim()
      if (file) {
        payload.attachmentName = file.name
        payload.attachmentBase64 = await fileToBase64(file)
      }

      const res = await fetch("/api/disputes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data?.error || "Failed to submit")
      }

      setPayslipId("")
      setDescription("")
      setFile(null)
      onDone?.()
    } catch (e: any) {
      setError(e?.message || "Something went wrong")
    } finally {
      setBusy(false)
    }
  }

  return (
    <section className={styles.card}>
      <h2>Submit</h2>

      <div className={styles.row}>
        <div className={styles.field}>
          <div className={styles.label}>Type</div>
          <select className={styles.select} value={type} onChange={e => setType(e.target.value as Mode)}>
            <option value="dispute">Dispute</option>
            <option value="claim">Reimbursement claim</option>
          </select>
        </div>

        <div className={styles.field}>
          <div className={styles.label}>Payslip reference</div>
          <input
            className={styles.input}
            value={payslipId}
            onChange={e => setPayslipId(e.target.value)}
            placeholder={type === "dispute" ? "Required for disputes" : "Optional"}
            disabled={type !== "dispute"}
          />
        </div>

        <div className={styles.field} style={{ gridColumn: "1 / -1" }}>
          <div className={styles.label}>Description</div>
          <textarea
            className={styles.textarea}
            value={description}
            onChange={e => setDescription(e.target.value)}
            placeholder="Describe the issue or claim details"
          />
          <div className={styles.help}>Minimum 5 characters</div>
        </div>

        <div className={styles.field} style={{ gridColumn: "1 / -1" }}>
          <div className={styles.label}>Attachment</div>
          <input className={styles.input} type="file" onChange={e => setFile(e.target.files?.[0] || null)} />
          <div className={styles.help}>Optional</div>
        </div>
      </div>

      {error ? <div className={styles.error}>{error}</div> : null}

      <div className={styles.actions}>
        <button className={styles.select} onClick={submit} disabled={!canSubmit}>
          {busy ? "Submitting..." : "Submit"}
        </button>
        <div className={styles.help}>Status flow: Pending → Specialist → Manager → Finance</div>
      </div>
    </section>
  )
}