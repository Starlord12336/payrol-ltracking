export { default as ProtectedRoute } from './ProtectedRoute';
export { default } from './ProtectedRoute';

