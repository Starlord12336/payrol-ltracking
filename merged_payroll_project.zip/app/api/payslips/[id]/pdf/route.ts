import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import { computeTotals, formatMoney } from "@/lib/utils"
import { PDFDocument, StandardFonts } from "pdf-lib"

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const payslip = db.getPayslip(params.id)
  if (!payslip) return NextResponse.json({ error: "Not found" }, { status: 404 })

  const totals = computeTotals(payslip.lines)
  const pdf = await PDFDocument.create()
  const page = pdf.addPage([595, 842])
  const font = await pdf.embedFont(StandardFonts.Helvetica)

  let y = 800
  const draw = (t: string, size = 12) => {
    page.drawText(t, { x: 50, y, size, font })
    y -= size + 6
  }

  draw(`Payslip ${payslip.id}`, 18)
  draw(`Employee: ${payslip.employeeName}`)
  draw(`Employee ID: ${payslip.employeeId}`)
  draw(`Period: ${payslip.periodLabel}`)
  draw(`Currency: ${payslip.currency}`)

  y -= 10
  payslip.lines.forEach(l => draw(`${l.label}: ${formatMoney(l.amount, payslip.currency)}`))

  y -= 10
  draw(`Earnings: ${formatMoney(totals.earnings, payslip.currency)}`)
  draw(`Deductions: ${formatMoney(totals.deductions, payslip.currency)}`)
  draw(`Net Salary: ${formatMoney(totals.net, payslip.currency)}`, 14)

  const bytes = await pdf.save()
  return new NextResponse(Buffer.from(bytes), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${payslip.id}.pdf"`
    }
  })
}
