import { NextResponse } from "next/server"
import { db } from "@/lib/db"

export async function GET() {
  return NextResponse.json(db.listDisputes())
}

export async function POST(req: Request) {
  const body = await req.json()
  const { type, payslipId, description, attachmentName, attachmentBase64 } = body ?? {}

  if (type !== "dispute" && type !== "claim") return NextResponse.json({ error: "Invalid type" }, { status: 400 })
  if (!description || String(description).trim().length < 5) return NextResponse.json({ error: "Invalid description" }, { status: 400 })
  if (type === "dispute" && !payslipId) return NextResponse.json({ error: "Payslip reference required" }, { status: 400 })

  const created = db.createDispute({
    type,
    payslipId: payslipId || undefined,
    description: String(description).trim(),
    attachmentName: attachmentName || undefined,
    attachmentBase64: attachmentBase64 || undefined
  })

  return NextResponse.json(created, { status: 201 })
}
