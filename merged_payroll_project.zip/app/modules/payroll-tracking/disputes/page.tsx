"use client"

import { useState } from "react"
import styles from "./disputes.module.css"
import { DisputeForm } from "@/components/DisputeForm"
import { ClaimsList } from "@/components/ClaimsList"

export default function Page() {
  const [refresh, setRefresh] = useState(0)
  return (
    <main className={styles.main}>
      <header className={styles.header}>
        <div className={styles.h1}>Claims & Disputes</div>
        <div className={styles.sub}>Submit payslip disputes or reimbursement claims and track status.</div>
      </header>

      <DisputeForm onDone={() => setRefresh(r => r + 1)} />
      <ClaimsList refresh={refresh} />
    </main>
  )
}