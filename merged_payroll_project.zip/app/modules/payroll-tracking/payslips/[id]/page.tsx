import styles from "./details.module.css"
import { BreakdownSection } from "@/components/BreakdownSection"
import { PayrollTable } from "@/components/PayrollTable"
import { DownloadPDFButton } from "@/components/DownloadPDFButton"
import { computeTotals, groupBy, formatMoney } from "@/lib/utils"
import type { Payslip } from "@/lib/types"

async function getPayslip(id: string): Promise<Payslip> {
  const base = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3001"
  const res = await fetch(`${base}/api/payslips/${id}`, { cache: "no-store" })
  if (!res.ok) throw new Error("Not found")
  return res.json()
}

export default async function Page({ params }: { params: { id: string } }) {
  const payslip = await getPayslip(params.id)
  const grouped = groupBy(payslip.lines, "category")
  const totals = computeTotals(payslip.lines)

  const credits = (cat: string) =>
    (grouped[cat] || []).map(l => ({ label: l.label, amount: l.amount, type: "credit" as const, note: l.note }))

  const debits = (cat: string) =>
    (grouped[cat] || []).map(l => ({ label: l.label, amount: l.amount, type: "debit" as const, note: l.note }))

  return (
    <main className={styles.main}>
      <header className={styles.header}>
        <div>
          <div className={styles.h1}>Payslip Details</div>
          <div className={styles.sub}>{payslip.periodLabel}</div>
        </div>
        <DownloadPDFButton payslipId={payslip.id} />
      </header>

      <div className={styles.grid}>
        <section className={styles.stack}>
          <div className={styles.card}>
            <div className={styles.kv}>
              <div className={styles.k}>Employee</div>
              <div className={styles.v}>{payslip.employeeName}</div>
              <div className={styles.k}>Employee ID</div>
              <div className={styles.v}>{payslip.employeeId}</div>
              <div className={styles.k}>Currency</div>
              <div className={styles.v}>{payslip.currency}</div>
            </div>
          </div>

          <BreakdownSection title="Earnings" currency={payslip.currency} items={[...credits("base"), ...credits("allowance"), ...credits("overtime"), ...credits("signing_bonus"), ...credits("termination_benefit")]} />
          <BreakdownSection title="Deductions" currency={payslip.currency} items={[...debits("deduction"), ...debits("tax"), ...debits("insurance"), ...debits("penalty"), ...debits("unpaid_leave")]} />

          <div className={styles.card}>
            <div className={styles.totals}>
              <div className={styles.totalRow}>
                <span className={styles.totalLabel}>Total earnings</span>
                <span className={styles.totalValue}>{formatMoney(totals.earnings, payslip.currency)}</span>
              </div>
              <div className={styles.totalRow}>
                <span className={styles.totalLabel}>Total deductions</span>
                <span className={styles.totalValue}>{formatMoney(totals.deductions, payslip.currency)}</span>
              </div>
              <div className={styles.totalRow}>
                <span className={styles.totalLabel}>Net salary</span>
                <span className={styles.totalValue}>{formatMoney(totals.net, payslip.currency)}</span>
              </div>
            </div>
          </div>
        </section>

        <section className={styles.stack}>
          <div className={styles.card}>
            <div className={styles.h1} style={{ fontSize: 18 }}>Full breakdown</div>
            <div className={styles.sub} style={{ marginTop: 6 }}>All payroll line items</div>
          </div>
          <PayrollTable lines={payslip.lines} currency={payslip.currency} />
        </section>
      </div>
    </main>
  )
}