import { PayrollLine } from "@/lib/types"
import { formatMoney } from "@/lib/utils"

export function PayrollTable({ lines, currency }: { lines: PayrollLine[]; currency: string }) {
  return (
    <div className="border rounded overflow-hidden">
      <table className="w-full">
        <thead>
          <tr className="text-left">
            <th className="p-2">Component</th>
            <th className="p-2">Category</th>
            <th className="p-2">Amount</th>
            <th className="p-2">Notes</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} className="border-t">
              <td className="p-2 font-medium">{l.label}</td>
              <td className="p-2">{l.category}</td>
              <td className="p-2">{formatMoney(l.amount, currency)}</td>
              <td className="p-2">{l.note ?? "-"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
