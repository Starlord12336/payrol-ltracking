"use client"

export function DownloadPDFButton({ id }: { id: string }) {
  return (
    <button
      onClick={() => (window.location.href = `/api/payslips/${id}/pdf`)}
      className="border px-4 py-2 rounded"
    >
      Download PDF
    </button>
  )
}
