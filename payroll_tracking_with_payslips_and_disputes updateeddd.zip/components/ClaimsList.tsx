"use client"

import { useEffect, useState } from "react"
import type { Dispute } from "@/lib/types"

function Badge({ text }: { text: string }) {
  const map: Record<string, string> = {
    Pending: "bg-gray-100 text-gray-800",
    Specialist: "bg-blue-50 text-blue-800",
    Manager: "bg-purple-50 text-purple-800",
    Finance: "bg-amber-50 text-amber-800",
    Completed: "bg-green-50 text-green-800",
    Rejected: "bg-red-50 text-red-800"
  }
  return (
    <span className={(map[text] || "bg-gray-100 text-gray-800") + " inline-flex items-center rounded-full px-2 py-1 text-xs font-semibold"}>
      {text}
    </span>
  )
}

export function ClaimsList({ refresh }: { refresh: number }) {
  const [items, setItems] = useState<Dispute[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    ;(async () => {
      setLoading(true)
      const res = await fetch("/api/disputes", { cache: "no-store" })
      const data = await res.json()
      if (alive) setItems(Array.isArray(data) ? data : [])
      setLoading(false)
    })()
    return () => {
      alive = false
    }
  }, [refresh])

  return (
    <section className="border p-4 rounded">
      <div className="text-lg font-semibold mb-2">Your Requests</div>
      {loading ? (
        <div className="text-sm opacity-70">Loading...</div>
      ) : items.length === 0 ? (
        <div className="text-sm opacity-70">No disputes/claims yet.</div>
      ) : (
        <div className="space-y-3">
          {items.map(d => (
            <div key={d.id} className="border rounded p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="font-semibold">
                  {d.type.toUpperCase()} <span className="opacity-60">•</span> {d.id}
                </div>
                <Badge text={d.status} />
              </div>
              <div className="text-sm opacity-80 mt-1">
                Payslip: {d.payslipId ?? "-"} • Submitted: {new Date(d.createdAtISO).toLocaleString()}
              </div>
              <p className="text-sm mt-2">{d.description}</p>
              {d.attachmentName ? <div className="text-sm mt-2 opacity-80">Attachment: {d.attachmentName}</div> : null}
            </div>
          ))}
        </div>
      )}
    </section>
  )
}
