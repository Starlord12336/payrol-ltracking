"use client"

import { useMemo, useState } from "react"
import type { DisputeType } from "@/lib/types"

function fileToBase64(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "")
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

export function DisputeForm({ onDone }: { onDone: () => void }) {
  const [type, setType] = useState<DisputeType>("dispute")
  const [payslipId, setPayslipId] = useState("")
  const [description, setDescription] = useState("")
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [ok, setOk] = useState<string | null>(null)

  const payslipRequired = useMemo(() => type === "dispute", [type])

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setError(null)
    setOk(null)

    if (payslipRequired && !payslipId.trim()) {
      setError("Payslip reference is required for disputes.")
      return
    }
    if (description.trim().length < 5) {
      setError("Description is too short.")
      return
    }

    setLoading(true)
    try {
      const attachmentBase64 = file ? await fileToBase64(file) : undefined
      const res = await fetch("/api/disputes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type,
          payslipId: payslipId.trim() || undefined,
          description: description.trim(),
          attachmentName: file?.name,
          attachmentBase64
        })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data?.error || "Failed")

      setOk("Submitted")
      setType("dispute")
      setPayslipId("")
      setDescription("")
      setFile(null)
      onDone()
    } catch (err: any) {
      setError(err?.message || "Something went wrong")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={submit} className="border p-4 rounded space-y-3">
      <div className="text-lg font-semibold">Submit a Dispute / Claim</div>

      <div className="grid gap-1">
        <label className="text-sm font-medium">Type</label>
        <select value={type} onChange={e => setType(e.target.value as DisputeType)} className="border rounded p-2">
          <option value="dispute">Dispute</option>
          <option value="claim">Claim</option>
        </select>
      </div>

      <div className="grid gap-1">
        <label className="text-sm font-medium">Payslip Reference {payslipRequired ? "(required)" : "(optional)"}</label>
        <input
          value={payslipId}
          onChange={e => setPayslipId(e.target.value)}
          className="border rounded p-2"
          placeholder="ps_1001"
        />
      </div>

      <div className="grid gap-1">
        <label className="text-sm font-medium">Description</label>
        <textarea
          value={description}
          onChange={e => setDescription(e.target.value)}
          rows={4}
          className="border rounded p-2"
          placeholder="Write your dispute or claim details..."
        />
      </div>

      <div className="grid gap-1">
        <label className="text-sm font-medium">Attachment Upload</label>
        <input type="file" accept="application/pdf,image/*" onChange={e => setFile(e.target.files?.[0] || null)} />
        {file ? <div className="text-sm opacity-80">{file.name}</div> : null}
      </div>

      {error ? <div className="text-sm text-red-600">{error}</div> : null}
      {ok ? <div className="text-sm text-green-700">{ok}</div> : null}

      <button disabled={loading} className="border px-4 py-2 rounded disabled:opacity-50">
        {loading ? "Submitting..." : "Submit"}
      </button>
    </form>
  )
}
