import { formatMoney } from "@/lib/utils"

export function BreakdownSection({
  title,
  currency,
  items
}: {
  title: string
  currency: string
  items: { label: string; amount: number; type: "credit" | "debit"; note?: string }[]
}) {
  if (!items.length) return null
  return (
    <section className="border p-4 rounded">
      <h3 className="font-semibold mb-2">{title}</h3>
      <div className="space-y-2">
        {items.map((i, k) => (
          <div key={k} className="flex items-start justify-between gap-4">
            <div>
              <div className="font-medium">{i.label}</div>
              {i.note ? <div className="text-sm opacity-70">{i.note}</div> : null}
            </div>
            <div className={i.type === "debit" ? "text-red-600 font-semibold" : "text-green-700 font-semibold"}>
              {i.type === "debit" ? "-" : "+"}
              {formatMoney(i.amount, currency)}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
