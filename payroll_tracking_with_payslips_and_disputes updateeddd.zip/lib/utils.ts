export function formatMoney(amount: number, currency = "EGP") {
  return new Intl.NumberFormat("en-US", { style: "currency", currency }).format(amount)
}

export function groupBy<T extends Record<string, any>>(arr: T[], key: keyof T) {
  return arr.reduce((acc: Record<string, T[]>, item) => {
    const k = String(item[key])
    acc[k] ||= []
    acc[k].push(item)
    return acc
  }, {})
}

export function nowISO() {
  return new Date().toISOString()
}

export function uid(prefix = "") {
  return prefix + Math.random().toString(36).slice(2) + Date.now()
}

export function computeTotals(lines: { amount: number; category: string }[]) {
  const credit = ["base", "allowance", "overtime", "signing_bonus", "termination_benefit"]
  const earnings = lines.filter(l => credit.includes(l.category)).reduce((s, l) => s + l.amount, 0)
  const deductions = lines.filter(l => !credit.includes(l.category)).reduce((s, l) => s + l.amount, 0)
  return { earnings, deductions, net: earnings - deductions }
}
