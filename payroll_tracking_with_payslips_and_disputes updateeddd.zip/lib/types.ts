export type PayrollLine = {
  label: string
  amount: number
  category:
    | "base"
    | "allowance"
    | "overtime"
    | "deduction"
    | "tax"
    | "insurance"
    | "penalty"
    | "unpaid_leave"
    | "signing_bonus"
    | "termination_benefit"
  note?: string
}

export type Payslip = {
  id: string
  employeeId: string
  employeeName: string
  periodLabel: string
  currency: string
  lines: PayrollLine[]
  createdAtISO: string
}

export type DisputeType = "dispute" | "claim"

export type DisputeStatus =
  | "Pending"
  | "Specialist"
  | "Manager"
  | "Finance"
  | "Completed"
  | "Rejected"

export type Dispute = {
  id: string
  type: DisputeType
  payslipId?: string
  description: string
  attachmentName?: string
  attachmentBase64?: string
  status: DisputeStatus
  createdAtISO: string
  updatedAtISO: string
  history: {
    atISO: string
    status: DisputeStatus
    by: string
  }[]
}
