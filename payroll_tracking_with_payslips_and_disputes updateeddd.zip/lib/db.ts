import { Payslip, Dispute } from "./types"
import { nowISO, uid } from "./utils"

declare global {
  var __DB__:
    | {
        payslips: Record<string, Payslip>
        disputes: Record<string, Dispute>
      }
    | undefined
}

function dbInstance() {
  if (!globalThis.__DB__) {
    globalThis.__DB__ = {
      payslips: {
        ps_1001: {
          id: "ps_1001",
          employeeId: "emp_1",
          employeeName: "Eyad Emara",
          periodLabel: "Nov 2025",
          currency: "EGP",
          createdAtISO: nowISO(),
          lines: [
            { label: "Base Salary", amount: 20000, category: "base" },
            { label: "Housing Allowance", amount: 3000, category: "allowance" },
            { label: "Transport Allowance", amount: 1000, category: "allowance" },
            { label: "Overtime", amount: 1200, category: "overtime" },
            { label: "Tax", amount: 1800, category: "tax" },
            { label: "Insurance", amount: 600, category: "insurance" },
            { label: "Penalty", amount: 200, category: "penalty" },
            { label: "Unpaid Leave", amount: 700, category: "unpaid_leave" }
          ]
        }
      },
      disputes: {}
    }
  }
  return globalThis.__DB__!
}

export const db = {
  getPayslip(id: string) {
    return dbInstance().payslips[id] ?? null
  },
  listDisputes() {
    return Object.values(dbInstance().disputes).sort((a, b) => b.createdAtISO.localeCompare(a.createdAtISO))
  },
  createDispute(
    data: Omit<Dispute, "id" | "status" | "createdAtISO" | "updatedAtISO" | "history">
  ) {
    const now = nowISO()
    const dispute: Dispute = {
      id: uid("dsp_"),
      status: "Pending",
      createdAtISO: now,
      updatedAtISO: now,
      history: [{ atISO: now, status: "Pending", by: "System" }],
      ...data
    }
    dbInstance().disputes[dispute.id] = dispute
    return dispute
  }
}
