/**
 * Employee Profile Module Types
 * Define types specific to this module
 */

// Add module-specific types here

