"use client"

import { useState } from "react"
import { DisputeForm } from "@/components/DisputeForm"
import { ClaimsList } from "@/components/ClaimsList"

export default function Page() {
  const [refresh, setRefresh] = useState(0)
  return (
    <main className="max-w-5xl mx-auto p-6 space-y-5">
      <header>
        <h1 className="text-2xl font-bold">Claims & Disputes</h1>
        <div className="opacity-80">Submit payslip disputes or reimbursement claims and track status.</div>
      </header>
      <DisputeForm onDone={() => setRefresh(r => r + 1)} />
      <ClaimsList refresh={refresh} />
    </main>
  )
}
