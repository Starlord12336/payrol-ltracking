import { BreakdownSection } from "@/components/BreakdownSection"
import { PayrollTable } from "@/components/PayrollTable"
import { DownloadPDFButton } from "@/components/DownloadPDFButton"
import { computeTotals, groupBy, formatMoney } from "@/lib/utils"
import type { Payslip } from "@/lib/types"

async function getPayslip(id: string): Promise<Payslip> {
  const base = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"
  const res = await fetch(`${base}/api/payslips/${id}`, { cache: "no-store" })
  if (!res.ok) throw new Error("Not found")
  return res.json()
}

export default async function Page({ params }: { params: { id: string } }) {
  const payslip = await getPayslip(params.id)
  const grouped = groupBy(payslip.lines, "category")
  const totals = computeTotals(payslip.lines)

  const creditCats = ["base", "allowance", "overtime", "signing_bonus", "termination_benefit"]
  const debitCats = ["deduction", "tax", "insurance", "penalty", "unpaid_leave"]

  const toItems = (cats: string[], type: "credit" | "debit") =>
    cats.flatMap(c => grouped[c] || []).map(l => ({ label: l.label, amount: l.amount, type, note: l.note }))

  return (
    <main className="max-w-5xl mx-auto p-6 space-y-5">
      <header className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Payslip Details</h1>
          <div className="opacity-80">{payslip.employeeName} • {payslip.periodLabel} • {payslip.id}</div>
        </div>
        <DownloadPDFButton id={payslip.id} />
      </header>

      <section className="grid md:grid-cols-3 gap-3">
        <div className="border rounded p-4">
          <div className="text-sm opacity-70">Earnings</div>
          <div className="text-xl font-bold">{formatMoney(totals.earnings, payslip.currency)}</div>
        </div>
        <div className="border rounded p-4">
          <div className="text-sm opacity-70">Deductions</div>
          <div className="text-xl font-bold">{formatMoney(totals.deductions, payslip.currency)}</div>
        </div>
        <div className="border rounded p-4">
          <div className="text-sm opacity-70">Net Salary</div>
          <div className="text-xl font-bold">{formatMoney(totals.net, payslip.currency)}</div>
        </div>
      </section>

      <section className="grid lg:grid-cols-2 gap-3">
        <BreakdownSection title="Earnings Breakdown" currency={payslip.currency} items={toItems(creditCats, "credit")} />
        <BreakdownSection title="Deductions Breakdown" currency={payslip.currency} items={toItems(debitCats, "debit")} />
      </section>

      <section className="space-y-2">
        <h2 className="text-lg font-semibold">Payroll Table</h2>
        <PayrollTable lines={payslip.lines} currency={payslip.currency} />
      </section>
    </main>
  )
}
