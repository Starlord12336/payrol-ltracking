# Payroll Pages

## Setup
```bash
npm i
npm run dev
```

## Routes
- Payslip details: `/payslips/ps_1001`
- Disputes: `/disputes`

## Environment
If needed, set:
```bash
NEXT_PUBLIC_BASE_URL=http://localhost:3000
```
