export const RefundSummary = ({ amount }: { amount: number }) => (
  <div>Refund Amount: ${amount}</div>
);