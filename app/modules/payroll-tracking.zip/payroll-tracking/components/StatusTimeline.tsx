export const StatusTimeline = ({ status }: { status: string }) => (
  <div>Status: {status}</div>
);