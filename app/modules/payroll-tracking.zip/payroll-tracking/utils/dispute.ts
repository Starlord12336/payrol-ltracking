export interface Dispute {
  refund: any;
  statusHistory: any;
  id: string;
  status: string;
  reason: string;
  createdAt: string;
  updatedAt: string;
}